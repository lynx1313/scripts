STORCLI JSON-SCHEMA: 
---------------------

--------------
Installation: 
--------------
1. Create a folder under /home/JSON-SCHEMA-FILES.
2. Unzip the JSON-SCHEMA-FILES.zip and copy all the schema files to 
	/home/JSON-SCHEMA-FILES (In any of the respective Operating Systems).

-------------------------
Command to Schema mapping:
-------------------------
Please refer to the Schema_mapping_list.xlsx for command to schema mapping.


