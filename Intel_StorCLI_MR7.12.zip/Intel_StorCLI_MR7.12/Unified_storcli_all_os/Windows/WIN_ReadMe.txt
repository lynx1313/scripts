Privileges:
The command prompt used to run storcli needs to have administrative privileges.

Sign verification:
command : signtool.exe verify /v /pa <storcli executable name>

Note: signtool.exe is required to validate the StorCLI's signature.
